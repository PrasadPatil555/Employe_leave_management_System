package com.employeeleavesystem.servlet;

import com.employeeleavesystem.dao.AttendanceDAO;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.time.LocalTime;

@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            HttpSession session = request.getSession(false);
            if (session != null) {
                int empId = (int) session.getAttribute("employeeId");

                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EmployeeLeaveManagement", "root", "Pratik@9595");
                AttendanceDAO dao = new AttendanceDAO(conn);

                // ✅ Update check-out time for today
                dao.updateCheckout(empId, Time.valueOf(LocalTime.now()));

                session.invalidate();
            }

            response.sendRedirect("jsp/login.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("jsp/error.jsp");
        }
    }
}
