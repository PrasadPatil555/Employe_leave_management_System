/*
 * package com.employeeleavesystem.servlet;
 * 
 * import com.employeeleavesystem.dao.AttendanceDAO; import
 * com.employeeleavesystem.dao.EmployeeDAO; import
 * com.employeeleavesystem.model.Attendance;
 * 
 * import javax.servlet.*; import javax.servlet.annotation.WebServlet; import
 * javax.servlet.http.*; import java.io.IOException; import java.sql.*;
 * 
 * @WebServlet("/AttendanceServlet") public class AttendanceServlet extends
 * HttpServlet { protected void doPost(HttpServletRequest request,
 * HttpServletResponse response) throws ServletException, IOException { try { //
 * Get username from session HttpSession session = request.getSession(false);
 * String username = (String) session.getAttribute("username");
 * 
 * if (username == null) { response.sendRedirect("login.jsp"); return; }
 * 
 * // Get employeeId using username EmployeeDAO empDao = new EmployeeDAO(); int
 * employeeId = empDao.getEmployeeIdByUsername(username);
 * 
 * // Prepare attendance object Attendance att = new Attendance();
 * att.setEmployeeId(employeeId);
 * att.setDate(Date.valueOf(request.getParameter("date")));
 * att.setCheckInTime(Time.valueOf(request.getParameter("checkIn")));
 * att.setCheckOutTime(Time.valueOf(request.getParameter("checkOut"))); //
 * Optional att.setStatus(request.getParameter("status"));
 * 
 * AttendanceDAO dao = new AttendanceDAO(); boolean success =
 * dao.markAttendance(att);
 * 
 * if (success) { response.
 * sendRedirect("jsp/attendance.jsp?msg=Attendance Recorded Successfully"); }
 * else {
 * response.sendRedirect("jsp/attendance.jsp?msg=Failed to Record Attendance");
 * }
 * 
 * } catch (Exception e) { e.printStackTrace();
 * response.sendRedirect("jsp/attendance.jsp?msg=Error Occurred"); } } }
 */
package com.employeeleavesystem.servlet;

import com.employeeleavesystem.dao.AttendanceDAO;
import com.employeeleavesystem.dao.EmployeeDAO;
import com.employeeleavesystem.model.Attendance;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/AttendanceServlet")
public class AttendanceServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            HttpSession session = request.getSession(false);
            String username = (String) session.getAttribute("username");

            if (username == null) {
                response.sendRedirect("login.jsp");
                return;
            }

            // Get employeeId using username
            EmployeeDAO empDao = new EmployeeDAO();
            int employeeId = empDao.getEmployeeIdByUsername(username);

            // Prepare attendance object
            Attendance att = new Attendance();
            att.setEmployeeId(employeeId);
            att.setAttendanceDate(Date.valueOf(request.getParameter("date"))); // ✅ Fixed method name
            att.setCheckInTime(Time.valueOf(request.getParameter("checkIn")));
            att.setCheckOutTime(Time.valueOf(request.getParameter("checkOut"))); // Optional
            att.setStatus(request.getParameter("status"));

            AttendanceDAO dao = new AttendanceDAO();
            boolean success = dao.markAttendance(att);

            if (success) {
                response.sendRedirect("jsp/attendance.jsp?msg=Attendance Recorded Successfully");
            } else {
                response.sendRedirect("jsp/attendance.jsp?msg=Failed to Record Attendance");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("jsp/attendance.jsp?msg=Error Occurred");
        }
    }
}

