package com.employeeleavesystem.servlet;


import com.employeeleavesystem.dao.EmployeeDAO;
import com.employeeleavesystem.model.Employee;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Employee emp = new Employee();
            emp.setFirstName(request.getParameter("firstName"));
            emp.setLastName(request.getParameter("lastName"));
            emp.setEmail(request.getParameter("email"));
            emp.setPhoneNumber(request.getParameter("phone"));
            emp.setDob(Date.valueOf(request.getParameter("dob")));
            emp.setGender(request.getParameter("gender"));
            emp.setJobTitle(request.getParameter("jobTitle"));
            emp.setDepartment(request.getParameter("department"));
            emp.setEmployeeType(request.getParameter("type"));
            emp.setDateOfJoining(Date.valueOf(request.getParameter("doj")));
            emp.setUsername(request.getParameter("username"));
            emp.setPasswordHash(request.getParameter("password")); // Plain for now
            emp.setRole(request.getParameter("role"));
            emp.setEmployeeStatus("Active");

            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EmployeeLeaveManagement", "root", "Pratik@9595");
            EmployeeDAO dao = new EmployeeDAO(conn);

            boolean added = dao.addEmployee(emp);
            if (added) {
                response.sendRedirect("jsp/login.jsp?msg=Registered successfully, please login");
            } else {
                response.sendRedirect("jsp/register.jsp?error=Failed to register");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("jsp/register.jsp?error=Exception occurred");
        }
    }
}
