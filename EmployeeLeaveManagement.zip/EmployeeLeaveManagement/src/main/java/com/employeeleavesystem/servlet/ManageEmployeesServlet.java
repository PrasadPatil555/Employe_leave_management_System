package com.employeeleavesystem.servlet;

import com.employeeleavesystem.dao.EmployeeDAO;
import com.employeeleavesystem.model.Employee;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/ManageEmployeesServlet")
public class ManageEmployeesServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            EmployeeDAO employeeDAO = new EmployeeDAO();
            List<Employee> employeeList = employeeDAO.getAllEmployees();

            request.setAttribute("employeeList", employeeList);
            request.getRequestDispatcher("/jsp/manage-employees.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp"); // Optional: redirect to a custom error page
        }
    }
}
