// Updated AttendanceViewServlet.java
package com.employeeleavesystem.servlet;

import com.employeeleavesystem.dao.AttendanceDAO;
import com.employeeleavesystem.model.Attendance;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/AttendanceViewServlet")
public class AttendanceViewServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String employeeUsername = (String) session.getAttribute("username");

        AttendanceDAO dao = new AttendanceDAO();
        List<Attendance> attendanceList = null;

        try {
            attendanceList = dao.getAttendanceByUsername(employeeUsername);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        request.setAttribute("attendanceList", attendanceList);
        request.getRequestDispatcher("jsp/my-attendance.jsp").forward(request, response);
    }
}
