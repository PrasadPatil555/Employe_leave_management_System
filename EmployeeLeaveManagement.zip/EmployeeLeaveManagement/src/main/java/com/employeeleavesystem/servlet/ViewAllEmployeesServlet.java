//package com.employeeleavesystem.servlet;
//
//import com.employeeleavesystem.dao.EmployeeDAO;
//import com.employeeleavesystem.model.Employee;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.*;
//import java.io.IOException;
//import java.util.List;
//
//@WebServlet("/ViewAllEmployeesServlet")
//public class ViewAllEmployeesServlet extends HttpServlet {
//    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        EmployeeDAO dao = new EmployeeDAO();
//        List<Employee> employeeList = dao.getAllEmployees();
//        request.setAttribute("employeeList", employeeList);
//        request.getRequestDispatcher("/jsp/view-all-employees.jsp").forward(request, response);
//    }
//}
package com.employeeleavesystem.servlet;

import com.employeeleavesystem.dao.EmployeeDAO;
import com.employeeleavesystem.model.Employee;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/ViewAllEmployeesServlet")
public class ViewAllEmployeesServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        EmployeeDAO dao = new EmployeeDAO();

        try {
            List<Employee> employeeList = dao.getAllEmployees();
            request.setAttribute("employeeList", employeeList);
            request.getRequestDispatcher("/jsp/view-all-employees.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error fetching employees: " + e.getMessage());
            request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
        }
    }
}
