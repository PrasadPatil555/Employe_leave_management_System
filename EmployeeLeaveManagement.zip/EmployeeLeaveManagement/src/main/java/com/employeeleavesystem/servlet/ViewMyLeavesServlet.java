//
//
//package com.employeeleavesystem.servlet;
//
//import com.employeeleavesystem.dao.LeaveRequestDAO;
//import com.employeeleavesystem.model.LeaveRequest;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.*;
//import java.io.IOException;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.util.List;
//
//@WebServlet("/ViewMyLeavesServlet")
//public class ViewMyLeavesServlet extends HttpServlet {
//    private LeaveRequestDAO dao;
//
//    @Override
//    public void init() {
//        try {
//            Connection conn = DriverManager.getConnection(
//                "jdbc:mysql://localhost:3306/EmployeeLeaveManagement", "root", "Pratik@9595"
//            );
//            dao = new LeaveRequestDAO(conn);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        try {
//            HttpSession session = request.getSession(false);
//            if (session == null || session.getAttribute("username") == null) {
//                response.sendRedirect("login.jsp");
//                return;
//            }
//
//            String username = (String) session.getAttribute("username");
//            List<LeaveRequest> leaveList = dao.getLeavesByUsername(username);
//
//            request.setAttribute("leaveList", leaveList);
//            request.getRequestDispatcher("jsp/my-leaves.jsp").forward(request, response);
//        } catch (Exception e) {
//            e.printStackTrace();
//            response.sendRedirect("dashboard.jsp?msg=Error fetching leaves");
//        }
//    }
//}

package com.employeeleavesystem.servlet;

import com.employeeleavesystem.dao.LeaveRequestDAO;
import com.employeeleavesystem.model.LeaveRequest;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;

@WebServlet("/ViewMyLeavesServlet")
public class ViewMyLeavesServlet extends HttpServlet {
    private LeaveRequestDAO dao;

    @Override
    public void init() {
        try {
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/EmployeeLeaveManagement", "root", "Pratik@9595"
            );
            dao = new LeaveRequestDAO(conn);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        try {
//            HttpSession session = request.getSession(false);
//            if (session == null || session.getAttribute("username") == null) {
//                response.sendRedirect("login.jsp");
//                return;
//            }
//
//            String username = (String) session.getAttribute("username");
//            List<LeaveRequest> leaveList = dao.getLeavesByUsername(username);
//
//            request.setAttribute("leaveList", leaveList);
//            request.getRequestDispatcher("jsp/my-leaves.jsp").forward(request, response);
//        } catch (Exception e) {
//            e.printStackTrace();
//            response.sendRedirect("dashboard.jsp?msg=Error fetching leaves");
//        }
//    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            HttpSession session = request.getSession(false);
            if (session == null || session.getAttribute("username") == null) {
                System.out.println("[ViewMyLeavesServlet] Session or username not found. Redirecting to login.jsp.");
                response.sendRedirect("login.jsp");
                return;
            }

            String username = (String) session.getAttribute("username");
            System.out.println("[ViewMyLeavesServlet] Fetching leaves for user: " + username);

            List<LeaveRequest> leaveList = dao.getLeavesByUsername(username);
            System.out.println("[ViewMyLeavesServlet] Leaves found: " + leaveList.size());

            request.setAttribute("leaveList", leaveList);
            request.getRequestDispatcher("jsp/my-leaves.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("dashboard.jsp?msg=Error fetching leaves");
        }
    }

    
}
