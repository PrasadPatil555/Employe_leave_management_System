/*
 * package com.employeeleavesystem.servlet;
 * 
 * import com.employeeleavesystem.dao.EmployeeDAO; import
 * com.employeeleavesystem.model.Employee;
 * 
 * import javax.servlet.*; import javax.servlet.annotation.WebServlet; import
 * javax.servlet.http.*; import java.io.IOException; import java.sql.Connection;
 * import java.sql.Date; import java.sql.DriverManager; import java.util.List;
 * 
 * @WebServlet("/EmployeeServlet") public class EmployeeServlet extends
 * HttpServlet { private Connection conn;
 * 
 * public void init() { try { conn = DriverManager.getConnection(
 * "jdbc:mysql://localhost:3306/EmployeeLeaveManagement", "root", "Pratik@9595"
 * ); } catch (Exception e) { e.printStackTrace(); } }
 * 
 * protected void doGet(HttpServletRequest request, HttpServletResponse
 * response) throws ServletException, IOException { String action =
 * request.getParameter("action");
 * 
 * try { EmployeeDAO dao = new EmployeeDAO(conn);
 * 
 * if ("edit".equals(action)) { int id =
 * Integer.parseInt(request.getParameter("id")); Employee emp =
 * dao.getEmployeeById(id); request.setAttribute("employee", emp);
 * request.getRequestDispatcher("jsp/employee-form.jsp").forward(request,
 * response); // Updated path } else if ("delete".equals(action)) { int id =
 * Integer.parseInt(request.getParameter("id")); dao.deleteEmployee(id);
 * response.sendRedirect("jsp/dashboard.jsp"); // Updated path } else {
 * List<Employee> list = dao.getAllEmployees();
 * request.setAttribute("employeeList", list);
 * request.getRequestDispatcher("jsp/dashboard.jsp").forward(request, response);
 * // Updated path } } catch (Exception e) { e.printStackTrace(); } }
 * 
 * protected void doPost(HttpServletRequest request, HttpServletResponse
 * response) throws ServletException, IOException { try { Employee emp = new
 * Employee(); emp.setFirstName(request.getParameter("firstName"));
 * emp.setLastName(request.getParameter("lastName"));
 * emp.setEmail(request.getParameter("email"));
 * emp.setPhoneNumber(request.getParameter("phone"));
 * emp.setDob(Date.valueOf(request.getParameter("dob"))); // Convert to SQL Date
 * emp.setGender(request.getParameter("gender"));
 * emp.setJobTitle(request.getParameter("jobTitle"));
 * emp.setDepartment(request.getParameter("department"));
 * emp.setEmployeeType(request.getParameter("employeeType"));
 * emp.setDateOfJoining(Date.valueOf(request.getParameter("dateOfJoining"))); //
 * Convert to SQL Date emp.setUsername(request.getParameter("username"));
 * emp.setPasswordHash(request.getParameter("password"));
 * emp.setRole(request.getParameter("role"));
 * 
 * EmployeeDAO dao = new EmployeeDAO(conn); String id =
 * request.getParameter("id");
 * 
 * if (id == null || id.isEmpty()) { dao.addEmployee(emp); } else {
 * emp.setEmployeeId(Integer.parseInt(id)); dao.updateEmployee(emp); }
 * 
 * response.sendRedirect("EmployeeServlet"); } catch (Exception e) {
 * e.printStackTrace(); } } }
 */

package com.employeeleavesystem.servlet;

import com.employeeleavesystem.dao.EmployeeDAO;
import com.employeeleavesystem.model.Employee;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.util.List;

@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
    private Connection conn;

    public void init() {
        try {
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/EmployeeLeaveManagement", "root", "Pratik@9595"
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            EmployeeDAO dao = new EmployeeDAO(conn);

            if ("edit".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                Employee emp = dao.getEmployeeById(id);
                request.setAttribute("employee", emp);
                request.getRequestDispatcher("jsp/employee-form.jsp").forward(request, response);
            } else if ("delete".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                dao.deleteEmployee(id);
                response.sendRedirect("jsp/dashboard.jsp");
            } else {
                List<Employee> list = dao.getAllEmployees();
                request.setAttribute("employeeList", list);
                request.getRequestDispatcher("jsp/dashboard.jsp").forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Employee emp = new Employee();
            emp.setFirstName(request.getParameter("firstName"));
            emp.setLastName(request.getParameter("lastName"));
            emp.setEmail(request.getParameter("email"));
            emp.setPhoneNumber(request.getParameter("phone"));
            emp.setDob(Date.valueOf(request.getParameter("dob")));
            emp.setGender(request.getParameter("gender"));
            emp.setJobTitle(request.getParameter("jobTitle"));
            emp.setDepartment(request.getParameter("department"));
            emp.setEmployeeType(request.getParameter("employeeType"));
            emp.setDateOfJoining(Date.valueOf(request.getParameter("dateOfJoining")));
            emp.setUsername(request.getParameter("username"));
            emp.setPasswordHash(request.getParameter("password"));
            emp.setRole(request.getParameter("role"));

            EmployeeDAO dao = new EmployeeDAO(conn);
            String id = request.getParameter("id");

            HttpSession session = request.getSession();

            if (id == null || id.isEmpty()) {
                dao.addEmployee(emp);
                session.setAttribute("message", "Employee added successfully!");
            } else {
                emp.setEmployeeId(Integer.parseInt(id));
                dao.updateEmployee(emp);
                session.setAttribute("message", "Employee updated successfully!");
            }

            response.sendRedirect("EmployeeServlet");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
