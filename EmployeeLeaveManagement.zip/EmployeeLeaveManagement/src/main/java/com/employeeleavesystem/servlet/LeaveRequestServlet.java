
package com.employeeleavesystem.servlet;

import com.employeeleavesystem.dao.LeaveRequestDAO;
import com.employeeleavesystem.model.LeaveRequest;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/LeaveRequestServlet")
public class LeaveRequestServlet extends HttpServlet {
    private LeaveRequestDAO dao;

    @Override
    public void init() {
        try {
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/EmployeeLeaveManagement", "root", "Pratik@9595"
            );
            dao = new LeaveRequestDAO(conn);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int employeeId = Integer.parseInt(request.getParameter("employeeId"));
            String leaveType = request.getParameter("leaveType");
            Date startDate = Date.valueOf(request.getParameter("startDate"));
            Date endDate = Date.valueOf(request.getParameter("endDate"));
            int leaveDays = Integer.parseInt(request.getParameter("leaveDays"));

            LeaveRequest lr = new LeaveRequest();
            lr.setEmployeeId(employeeId);
            lr.setLeaveType(leaveType);
            lr.setStartDate(startDate);
            lr.setEndDate(endDate);
            lr.setLeaveDays(leaveDays);
            lr.setLeaveStatus("Pending"); // default
            lr.setApprovedBy(null);
            lr.setApprovalDate(null);

            dao.applyLeave(lr);

            // ✅ Redirect back with success message
            response.sendRedirect("jsp/leave-apply.jsp?msg=Leave request submitted successfully!");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("jsp/leave-apply.jsp?msg=Error submitting leave request.");
        }
    }
}

