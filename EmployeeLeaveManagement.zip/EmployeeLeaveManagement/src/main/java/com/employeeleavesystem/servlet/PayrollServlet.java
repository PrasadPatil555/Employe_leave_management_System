package com.employeeleavesystem.servlet;

import com.employeeleavesystem.dao.PayrollDAO;
import com.employeeleavesystem.model.Payroll;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.*;
import java.util.List;

@WebServlet("/PayrollServlet")
public class PayrollServlet extends HttpServlet {

    // ✅ Handle payroll creation (POST)
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Payroll payroll = new Payroll();
            payroll.setEmployeeId(Integer.parseInt(request.getParameter("employeeId")));
            payroll.setSalary(new BigDecimal(request.getParameter("salary")));
            payroll.setBankAccount(request.getParameter("bankAccount"));
            payroll.setTaxDeductions(new BigDecimal(request.getParameter("tax")));

            // Set today's date as payment date (optional)
            payroll.setPaymentDate(new java.sql.Date(System.currentTimeMillis()));

            // DB connection + DAO call
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/EmployeeLeaveManagement", "root", "Pratik@9595");
            PayrollDAO dao = new PayrollDAO(conn);

            boolean success = dao.processPayroll(payroll);

            if (success) {
                response.sendRedirect("jsp/dashboard.jsp?msg=Payroll recorded");
            } else {
                response.sendRedirect("jsp/dashboard.jsp?error=Failed to insert payroll");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("jsp/dashboard.jsp?error=Payroll processing failed");
        }
    }

    // ✅ Handle payroll viewing (GET)
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int employeeId = Integer.parseInt(request.getParameter("employeeId"));

            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/EmployeeLeaveManagement", "root", "Pratik@9595");
            PayrollDAO dao = new PayrollDAO(conn);

            List<Payroll> payrollList = dao.getPayrollByEmployee(employeeId);
            request.setAttribute("payrollList", payrollList);

            request.getRequestDispatcher("jsp/view-payroll.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("jsp/dashboard.jsp?error=Error fetching payroll data");
        }
    }
}
