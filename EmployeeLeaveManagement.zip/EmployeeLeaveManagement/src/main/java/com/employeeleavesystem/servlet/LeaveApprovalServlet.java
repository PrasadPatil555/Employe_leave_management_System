package com.employeeleavesystem.servlet;

import com.employeeleavesystem.dao.LeaveRequestDAO;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/LeaveApprovalServlet")
public class LeaveApprovalServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int leaveId = Integer.parseInt(request.getParameter("leaveId"));
            String action = request.getParameter("action"); // "Approved" or "Rejected"
            HttpSession session = request.getSession();
            String approverUsername = (String) session.getAttribute("username");

            // ✅ Connect to DB
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EmployeeLeaveManagement", "root", "Pratik@9595");

            // ✅ Get employeeId of approver using username
            int approvedBy = 0;
            PreparedStatement ps = conn.prepareStatement("SELECT employee_id FROM Employee WHERE username = ?");
            ps.setString(1, approverUsername);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                approvedBy = rs.getInt("employee_id");
            }

            // ✅ Update leave status
            LeaveRequestDAO dao = new LeaveRequestDAO(conn);
            dao.updateLeaveStatus(leaveId, action, approvedBy);

            response.sendRedirect("ManagerDashboardServlet");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("jsp/error.jsp");
        }
    }
}
