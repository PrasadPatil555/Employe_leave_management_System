package com.employeeleavesystem.servlet;

import com.employeeleavesystem.dao.AttendanceDAO;
import com.employeeleavesystem.dao.EmployeeDAO;
import com.employeeleavesystem.model.Attendance;
import com.employeeleavesystem.model.Employee;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String username = request.getParameter("username");
            String password = request.getParameter("password");

            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/EmployeeLeaveManagement", "root", "Pratik@9595");

            EmployeeDAO dao = new EmployeeDAO(conn);
            Employee emp = dao.authenticate(username, password);

            if (emp != null) {
                HttpSession session = request.getSession();
                session.setAttribute("employee", emp);
                session.setAttribute("employeeId", emp.getEmployeeId());
                session.setAttribute("username", emp.getUsername());
                session.setAttribute("role", emp.getRole());

                // ✅ Automatically mark check-in
                Attendance attendance = new Attendance();
                attendance.setEmployeeId(emp.getEmployeeId());
                attendance.setAttendanceDate(Date.valueOf(LocalDate.now())); // ✅ FIXED
                attendance.setCheckInTime(Time.valueOf(LocalTime.now()));
                attendance.setCheckOutTime(null);
                attendance.setStatus("Present");

                AttendanceDAO attDao = new AttendanceDAO(conn);
                attDao.markAttendance(attendance);

                response.sendRedirect(request.getContextPath() + "/jsp/dashboard.jsp");
            } else {
                response.sendRedirect(request.getContextPath() + "/jsp/login.jsp?error=Invalid+credentials");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/jsp/login.jsp?error=Server+error");
        }
    }
}
