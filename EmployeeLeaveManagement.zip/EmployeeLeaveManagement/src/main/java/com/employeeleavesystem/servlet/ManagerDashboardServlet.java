/*
 * package com.employeeleavesystem.servlet;
 * 
 * import com.employeeleavesystem.dao.LeaveRequestDAO; import
 * com.employeeleavesystem.model.LeaveRequest;
 * 
 * import javax.servlet.*; import javax.servlet.annotation.WebServlet; import
 * javax.servlet.http.*; import java.io.IOException; import java.sql.*; import
 * java.util.List;
 * 
 * @WebServlet("/ManagerDashboardServlet") public class ManagerDashboardServlet
 * extends HttpServlet { protected void doGet(HttpServletRequest request,
 * HttpServletResponse response) throws ServletException, IOException { try {
 * Connection conn = DriverManager.getConnection(
 * "jdbc:mysql://localhost:3306/EmployeeLeaveManagement", "root", "Pratik@9595"
 * ); LeaveRequestDAO dao = new LeaveRequestDAO(conn); List<LeaveRequest>
 * leaveList = dao.getAllRequests();
 * 
 * request.setAttribute("leaveList", leaveList); RequestDispatcher rd =
 * request.getRequestDispatcher("/jsp/dashboard-manager.jsp");
 * rd.forward(request, response); } catch (Exception e) { e.printStackTrace();
 * response.sendRedirect("jsp/error.jsp"); } } }
 */
package com.employeeleavesystem.servlet;

import com.employeeleavesystem.dao.LeaveRequestDAO;
import com.employeeleavesystem.model.LeaveRequest;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.List;

@WebServlet("/ManagerDashboardServlet")
public class ManagerDashboardServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/EmployeeLeaveManagement", "root", "Pratik@9595"
            );
            LeaveRequestDAO dao = new LeaveRequestDAO(conn);
            List<LeaveRequest> leaveList = dao.getAllRequests();

            // ✅ Print size in server console to confirm
            System.out.println("Leave list size: " + leaveList.size());

            request.setAttribute("leaveList", leaveList);
            RequestDispatcher rd = request.getRequestDispatcher("/jsp/dashboard-manager.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("jsp/error.jsp");
        }
    }
}
