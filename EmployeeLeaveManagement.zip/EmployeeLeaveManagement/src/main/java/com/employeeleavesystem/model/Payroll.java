package com.employeeleavesystem.model;

import java.math.BigDecimal;
import java.sql.Date;

public class Payroll {
    private int payrollId;
    private int employeeId;
    private BigDecimal salary;
    private String bankAccount;
    private BigDecimal taxDeductions;
    private BigDecimal netSalary;
    private Date paymentDate;

    // Getters and Setters
    public int getPayrollId() { return payrollId; }
    public void setPayrollId(int payrollId) { this.payrollId = payrollId; }

    public int getEmployeeId() { return employeeId; }
    public void setEmployeeId(int employeeId) { this.employeeId = employeeId; }

    public BigDecimal getSalary() { return salary; }
    public void setSalary(BigDecimal salary) { this.salary = salary; }

    public String getBankAccount() { return bankAccount; }
    public void setBankAccount(String bankAccount) { this.bankAccount = bankAccount; }

    public BigDecimal getTaxDeductions() { return taxDeductions; }
    public void setTaxDeductions(BigDecimal taxDeductions) { this.taxDeductions = taxDeductions; }

    public BigDecimal getNetSalary() { return netSalary; }
    public void setNetSalary(BigDecimal netSalary) { this.netSalary = netSalary; }

    public Date getPaymentDate() { return paymentDate; }
    public void setPaymentDate(Date paymentDate) { this.paymentDate = paymentDate; }
}
