//
//
//package com.employeeleavesystem.dao;
//
//import com.employeeleavesystem.model.LeaveRequest;
//
//import java.sql.*;
//import java.util.*;
//
//public class LeaveRequestDAO {
//    private Connection conn;
//
//    public LeaveRequestDAO(Connection conn) {
//        this.conn = conn;
//    }
//
//    // Apply for leave
//    public boolean applyLeave(LeaveRequest request) throws SQLException {
//        String sql = "INSERT INTO LeaveRequests " +
//                "(employee_id, leave_type, start_date, end_date, leave_days, leave_status, approved_by, approval_date, applied_on) " +
//                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
//
//        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
//            stmt.setInt(1, request.getEmployeeId());
//            stmt.setString(2, request.getLeaveType());
//            stmt.setDate(3, request.getStartDate());
//            stmt.setDate(4, request.getEndDate());
//            stmt.setInt(5, request.getLeaveDays());
//            stmt.setString(6, request.getLeaveStatus());
//
//            if (request.getApprovedBy() != null) {
//                stmt.setInt(7, request.getApprovedBy());
//            } else {
//                stmt.setNull(7, Types.INTEGER);
//            }
//
//            if (request.getApprovalDate() != null) {
//                stmt.setTimestamp(8, new Timestamp(request.getApprovalDate().getTime()));
//            } else {
//                stmt.setNull(8, Types.TIMESTAMP);
//            }
//
//            return stmt.executeUpdate() > 0;
//        }
//    }
//
//    // Get all leave requests (admin/manager use)
//    public List<LeaveRequest> getAllRequests() throws SQLException {
//        List<LeaveRequest> list = new ArrayList<>();
//        String sql = "SELECT * FROM LeaveRequests";
//
//        try (Statement stmt = conn.createStatement();
//             ResultSet rs = stmt.executeQuery(sql)) {
//            while (rs.next()) {
//                LeaveRequest req = extractLeaveRequest(rs);
//                list.add(req);
//            }
//        }
//
//        return list;
//    }
//
//    // Update leave status
//    public boolean updateLeaveStatus(int leaveId, String status, int approvedBy) throws SQLException {
//        String sql = "UPDATE LeaveRequests SET leave_status = ?, approved_by = ?, approval_date = NOW() WHERE leave_id = ?";
//        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
//            stmt.setString(1, status);
//            stmt.setInt(2, approvedBy);
//            stmt.setInt(3, leaveId);
//            return stmt.executeUpdate() > 0;
//        }
//    }
//
//    // Get leaves by username
//    public List<LeaveRequest> getLeavesByUsername(String username) throws SQLException {
//        List<LeaveRequest> list = new ArrayList<>();
//        String sql = "SELECT lr.* FROM LeaveRequests lr " +
//                     "JOIN Employee e ON lr.employee_id = e.employee_id " +
//                     "WHERE e.username = ? ORDER BY lr.applied_on DESC";
//
//        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
//            stmt.setString(1, username);
//            try (ResultSet rs = stmt.executeQuery()) {
//                while (rs.next()) {
//                    LeaveRequest req = extractLeaveRequest(rs);
//                    list.add(req);
//                }
//            }
//        }
//
//        return list;
//    }
//
//    // Utility method to extract LeaveRequest from ResultSet
//    private LeaveRequest extractLeaveRequest(ResultSet rs) throws SQLException {
//        LeaveRequest req = new LeaveRequest();
//        req.setLeaveId(rs.getInt("leave_id"));
//        req.setEmployeeId(rs.getInt("employee_id"));
//        req.setLeaveType(rs.getString("leave_type"));
//        req.setStartDate(rs.getDate("start_date"));
//        req.setEndDate(rs.getDate("end_date"));
//        req.setLeaveDays(rs.getInt("leave_days"));
//        req.setLeaveStatus(rs.getString("leave_status"));
//
//        Timestamp appliedOn = rs.getTimestamp("applied_on");
//        if (appliedOn != null) req.setAppliedOn(appliedOn);
//
//        int approvedBy = rs.getInt("approved_by");
//        if (!rs.wasNull()) req.setApprovedBy(approvedBy);
//        else req.setApprovedBy(null);
//
//        Timestamp approvalDate = rs.getTimestamp("approval_date");
//        if (approvalDate != null) req.setApprovalDate(approvalDate);
//
//        return req;
//    }
//}

package com.employeeleavesystem.dao;

import com.employeeleavesystem.model.LeaveRequest;

import java.sql.*;
import java.util.*;

public class LeaveRequestDAO {
    private Connection conn;

    public LeaveRequestDAO(Connection conn) {
        this.conn = conn;
    }

    // Apply for leave
    public boolean applyLeave(LeaveRequest request) throws SQLException {
        String sql = "INSERT INTO LeaveRequests " +
                "(employee_id, leave_type, start_date, end_date, leave_days, leave_status, approved_by, approval_date, applied_on) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, request.getEmployeeId());
            stmt.setString(2, request.getLeaveType());
            stmt.setDate(3, request.getStartDate());
            stmt.setDate(4, request.getEndDate());
            stmt.setInt(5, request.getLeaveDays());
            stmt.setString(6, request.getLeaveStatus());

            if (request.getApprovedBy() != null) {
                stmt.setInt(7, request.getApprovedBy());
            } else {
                stmt.setNull(7, Types.INTEGER);
            }

            if (request.getApprovalDate() != null) {
                stmt.setTimestamp(8, new Timestamp(request.getApprovalDate().getTime()));
            } else {
                stmt.setNull(8, Types.TIMESTAMP);
            }

            return stmt.executeUpdate() > 0;
        }
    }

    // Get all leave requests (for Admin/Manager)
    public List<LeaveRequest> getAllRequests() throws SQLException {
        List<LeaveRequest> list = new ArrayList<>();
        String sql = "SELECT * FROM LeaveRequests";

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(extractLeaveRequest(rs));
            }
        }

        return list;
    }

    // Update leave status
    public boolean updateLeaveStatus(int leaveId, String status, int approvedBy) throws SQLException {
        String sql = "UPDATE LeaveRequests SET leave_status = ?, approved_by = ?, approval_date = NOW() WHERE leave_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setInt(2, approvedBy);
            stmt.setInt(3, leaveId);
            return stmt.executeUpdate() > 0;
        }
    }

    // Get leave requests by employee username
//    public List<LeaveRequest> getLeavesByUsername(String username) throws SQLException {
//        List<LeaveRequest> list = new ArrayList<>();
//        String sql = "SELECT lr.* FROM LeaveRequests lr " +
//                     "JOIN Employee e ON lr.employee_id = e.employee_id " +
//                     "WHERE e.username = ? ORDER BY lr.applied_on DESC";
//
//        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
//            stmt.setString(1, username);
//            try (ResultSet rs = stmt.executeQuery()) {
//                while (rs.next()) {
//                    list.add(extractLeaveRequest(rs));
//                }
//            }
//        }
//
//        return list;
//    }
    public List<LeaveRequest> getLeavesByUsername(String username) throws SQLException {
        List<LeaveRequest> list = new ArrayList<>();
        String sql = "SELECT lr.* FROM LeaveRequests lr " +
                     "JOIN Employee e ON lr.employee_id = e.employee_id " +
                     "WHERE e.username = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    LeaveRequest req = extractLeaveRequest(rs);
                    list.add(req);
                }
            }
        }
        System.out.println("Leave list size for user '" + username + "': " + list.size());
        return list;
    }



    // Private helper to extract LeaveRequest from ResultSet
    private LeaveRequest extractLeaveRequest(ResultSet rs) throws SQLException {
        LeaveRequest req = new LeaveRequest();
        req.setLeaveId(rs.getInt("leave_id"));
        req.setEmployeeId(rs.getInt("employee_id"));
        req.setLeaveType(rs.getString("leave_type"));
        req.setStartDate(rs.getDate("start_date"));
        req.setEndDate(rs.getDate("end_date"));
        req.setLeaveDays(rs.getInt("leave_days"));
        req.setLeaveStatus(rs.getString("leave_status"));

        Timestamp appliedOn = rs.getTimestamp("applied_on");
        if (appliedOn != null) {
            req.setAppliedOn(appliedOn);
        }

        int approvedBy = rs.getInt("approved_by");
        if (!rs.wasNull()) {
            req.setApprovedBy(approvedBy);
        } else {
            req.setApprovedBy(null);
        }

        Timestamp approvalDate = rs.getTimestamp("approval_date");
        if (approvalDate != null) {
            req.setApprovalDate(approvalDate);
        }

        return req;
    }
}
