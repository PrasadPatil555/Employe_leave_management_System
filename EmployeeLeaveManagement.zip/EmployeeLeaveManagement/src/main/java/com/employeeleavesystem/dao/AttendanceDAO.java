package com.employeeleavesystem.dao;

import com.employeeleavesystem.model.Attendance;
import java.sql.*;
import java.util.*;

public class AttendanceDAO {
    private Connection conn;

    public AttendanceDAO() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            this.conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/employeeleavemanagement", "root", "Pratik@9595");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public AttendanceDAO(Connection conn) {
        this.conn = conn;
    }

    public boolean markAttendance(Attendance attendance) throws SQLException {
        String sql = "INSERT INTO Attendance (employee_id, attendance_date, check_in_time, check_out_time, status) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, attendance.getEmployeeId());
        stmt.setDate(2, attendance.getAttendanceDate());
        stmt.setTime(3, attendance.getCheckInTime());
        stmt.setTime(4, attendance.getCheckOutTime());
        stmt.setString(5, attendance.getStatus());
        return stmt.executeUpdate() > 0;
    }

    public List<Attendance> getAttendanceByEmployee(int employeeId) throws SQLException {
        List<Attendance> list = new ArrayList<>();
        String sql = "SELECT * FROM Attendance WHERE employee_id = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, employeeId);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Attendance a = new Attendance();
            a.setAttendanceId(rs.getInt("attendance_id"));
            a.setEmployeeId(rs.getInt("employee_id"));
            a.setAttendanceDate(rs.getDate("attendance_date"));
            a.setCheckInTime(rs.getTime("check_in_time"));
            a.setCheckOutTime(rs.getTime("check_out_time"));
            a.setStatus(rs.getString("status"));
            list.add(a);
        }
        return list;
    }

    public List<Attendance> getAttendanceByUsername(String username) throws SQLException {
        List<Attendance> list = new ArrayList<>();
        String sql = "SELECT a.* FROM Attendance a JOIN Employee e ON a.employee_id = e.employee_id WHERE e.username = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, username);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Attendance a = new Attendance();
            a.setAttendanceId(rs.getInt("attendance_id"));
            a.setEmployeeId(rs.getInt("employee_id"));
            a.setAttendanceDate(rs.getDate("attendance_date"));
            a.setCheckInTime(rs.getTime("check_in_time"));
            a.setCheckOutTime(rs.getTime("check_out_time"));
            a.setStatus(rs.getString("status"));
            list.add(a);
        }
        return list;
    }

    public boolean updateCheckout(int employeeId, Time checkoutTime) throws SQLException {
        String sql = "UPDATE Attendance SET check_out_time = ? WHERE employee_id = ? AND attendance_date = CURDATE()";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setTime(1, checkoutTime);
        stmt.setInt(2, employeeId);
        return stmt.executeUpdate() > 0;
    }
}
