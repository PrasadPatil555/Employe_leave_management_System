/*
 * package com.employeeleavesystem.dao; import
 * com.employeeleavesystem.model.Employee; import java.sql.*; import
 * java.util.*;
 * 
 * public class EmployeeDAO { private Connection conn;
 * 
 * public EmployeeDAO(Connection conn) { this.conn = conn; }
 * 
 * public boolean addEmployee(Employee emp) throws SQLException { String sql =
 * "INSERT INTO Employee (first_name, last_name, email, phone_number, dob, gender, job_title, department, employee_type, date_of_joining, manager_id, username, password_hash, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
 * ; PreparedStatement stmt = conn.prepareStatement(sql); stmt.setString(1,
 * emp.getFirstName()); stmt.setString(2, emp.getLastName()); stmt.setString(3,
 * emp.getEmail()); stmt.setString(4, emp.getPhoneNumber()); stmt.setDate(5,
 * emp.getDob()); stmt.setString(6, emp.getGender()); stmt.setString(7,
 * emp.getJobTitle()); stmt.setString(8, emp.getDepartment()); stmt.setString(9,
 * emp.getEmployeeType()); stmt.setDate(10, emp.getDateOfJoining());
 * stmt.setObject(11, emp.getManagerId(), java.sql.Types.INTEGER);
 * stmt.setString(12, emp.getUsername()); stmt.setString(13,
 * emp.getPasswordHash()); stmt.setString(14, emp.getRole()); return
 * stmt.executeUpdate() > 0; }
 * 
 * 
 * public List<Employee> getAllEmployees() throws SQLException { List<Employee>
 * list = new ArrayList<>(); String sql = "SELECT * FROM Employee"; Statement
 * stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql);
 * 
 * while (rs.next()) { Employee emp = new Employee();
 * emp.setEmployeeId(rs.getInt("employee_id"));
 * emp.setFirstName(rs.getString("first_name"));
 * emp.setLastName(rs.getString("last_name"));
 * emp.setEmail(rs.getString("email"));
 * emp.setPhoneNumber(rs.getString("phone_number"));
 * emp.setDob(rs.getDate("dob")); emp.setGender(rs.getString("gender"));
 * emp.setJobTitle(rs.getString("job_title"));
 * emp.setDepartment(rs.getString("department"));
 * emp.setEmployeeType(rs.getString("employee_type"));
 * emp.setDateOfJoining(rs.getDate("date_of_joining"));
 * emp.setManagerId(rs.getInt("manager_id"));
 * emp.setEmployeeStatus(rs.getString("employee_status"));
 * emp.setUsername(rs.getString("username")); emp.setRole(rs.getString("role"));
 * return (List<Employee>) emp; } return list; }
 * 
 * 
 * public List<Employee> getAllEmployees() throws SQLException { List<Employee>
 * list = new ArrayList<>(); String sql = "SELECT * FROM Employee"; Statement
 * stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql);
 * 
 * while (rs.next()) { Employee emp = new Employee();
 * emp.setEmployeeId(rs.getInt("employee_id"));
 * emp.setFirstName(rs.getString("first_name"));
 * emp.setLastName(rs.getString("last_name"));
 * emp.setEmail(rs.getString("email"));
 * emp.setPhoneNumber(rs.getString("phone_number"));
 * emp.setDob(rs.getDate("dob")); emp.setGender(rs.getString("gender"));
 * emp.setJobTitle(rs.getString("job_title"));
 * emp.setDepartment(rs.getString("department"));
 * emp.setEmployeeType(rs.getString("employee_type"));
 * emp.setDateOfJoining(rs.getDate("date_of_joining"));
 * emp.setManagerId(rs.getInt("manager_id"));
 * emp.setEmployeeStatus(rs.getString("employee_status"));
 * emp.setUsername(rs.getString("username")); emp.setRole(rs.getString("role"));
 * 
 * list.add(emp); // ✅ Add each employee to the list }
 * 
 * return list; // ✅ Now return the list properly }
 * 
 * 
 * public boolean deleteEmployee(int id) throws SQLException { String sql =
 * "DELETE FROM Employee WHERE employee_id = ?"; PreparedStatement stmt =
 * conn.prepareStatement(sql); stmt.setInt(1, id); return stmt.executeUpdate() >
 * 0; }
 * 
 * public Employee getEmployeeById(int id) throws SQLException { String sql =
 * "SELECT * FROM Employee WHERE employee_id = ?"; PreparedStatement stmt =
 * conn.prepareStatement(sql); stmt.setInt(1, id); ResultSet rs =
 * stmt.executeQuery(); if (rs.next()) { Employee emp = new Employee();
 * emp.setEmployeeId(rs.getInt("employee_id"));
 * emp.setFirstName(rs.getString("first_name"));
 * emp.setLastName(rs.getString("last_name"));
 * emp.setEmail(rs.getString("email"));
 * emp.setPhoneNumber(rs.getString("phone_number"));
 * emp.setDob(rs.getDate("dob")); emp.setGender(rs.getString("gender"));
 * emp.setJobTitle(rs.getString("job_title"));
 * emp.setDepartment(rs.getString("department"));
 * emp.setEmployeeType(rs.getString("employee_type"));
 * emp.setDateOfJoining(rs.getDate("date_of_joining"));
 * emp.setManagerId(rs.getInt("manager_id"));
 * emp.setEmployeeStatus(rs.getString("employee_status"));
 * emp.setUsername(rs.getString("username")); emp.setRole(rs.getString("role"));
 * return emp; } return null; }
 * 
 * public boolean updateEmployee(Employee emp) throws SQLException { String sql
 * =
 * "UPDATE Employee SET first_name=?, last_name=?, email=?, phone_number=?, dob=?, gender=?, job_title=?, department=?, employee_type=?, date_of_joining=?, manager_id=?, employee_status=? WHERE employee_id=?"
 * ; PreparedStatement stmt = conn.prepareStatement(sql); stmt.setString(1,
 * emp.getFirstName()); stmt.setString(2, emp.getLastName()); stmt.setString(3,
 * emp.getEmail()); stmt.setString(4, emp.getPhoneNumber()); stmt.setDate(5,
 * emp.getDob()); stmt.setString(6, emp.getGender()); stmt.setString(7,
 * emp.getJobTitle()); stmt.setString(8, emp.getDepartment()); stmt.setString(9,
 * emp.getEmployeeType()); stmt.setDate(10, emp.getDateOfJoining());
 * stmt.setObject(11, emp.getManagerId(), java.sql.Types.INTEGER);
 * stmt.setString(12, emp.getEmployeeStatus()); stmt.setInt(13,
 * emp.getEmployeeId()); return stmt.executeUpdate() > 0; }
 * 
 * // ✅ LOGIN/AUTHENTICATE method for LoginServlet public Employee
 * authenticate(String username, String password) throws SQLException { String
 * sql = "SELECT * FROM Employee WHERE username = ? AND password_hash = ?";
 * PreparedStatement stmt = conn.prepareStatement(sql); stmt.setString(1,
 * username); stmt.setString(2, password); ResultSet rs = stmt.executeQuery();
 * 
 * if (rs.next()) { Employee emp = new Employee();
 * emp.setEmployeeId(rs.getInt("employee_id"));
 * emp.setFirstName(rs.getString("first_name"));
 * emp.setLastName(rs.getString("last_name"));
 * emp.setUsername(rs.getString("username")); emp.setRole(rs.getString("role"));
 * return emp; } return null; }
 * 
 * // ✅ No-arg constructor public EmployeeDAO() { try {
 * Class.forName("com.mysql.cj.jdbc.Driver"); this.conn =
 * DriverManager.getConnection(
 * "jdbc:mysql://localhost:3306/employeeleavemanagement", "root", "Pratik@9595"
 * ); } catch (Exception e) { e.printStackTrace(); } }
 * 
 * // ✅ Get employee ID by username public int getEmployeeIdByUsername(String
 * username) throws SQLException { String sql =
 * "SELECT employee_id FROM Employee WHERE username = ?"; PreparedStatement stmt
 * = conn.prepareStatement(sql); stmt.setString(1, username); ResultSet rs =
 * stmt.executeQuery(); if (rs.next()) { return rs.getInt("employee_id"); } else
 * { throw new SQLException("Employee not found for username: " + username); } }
 * 
 * }
 * 
 * 
 * 
 */


package com.employeeleavesystem.dao;

import com.employeeleavesystem.model.Employee;
import java.sql.*;
import java.util.*;

public class EmployeeDAO {
    private Connection conn;

    // ✅ Constructor with Connection parameter
    public EmployeeDAO(Connection conn) {
        this.conn = conn;
    }

    // ✅ No-arg constructor with DB connection setup
    public EmployeeDAO() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            this.conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/employeeleavemanagement", "root", "Pratik@9595"
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ✅ Add employee
    public boolean addEmployee(Employee emp) throws SQLException {
        String sql = "INSERT INTO Employee (first_name, last_name, email, phone_number, dob, gender, job_title, department, employee_type, date_of_joining, manager_id, username, password_hash, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, emp.getFirstName());
        stmt.setString(2, emp.getLastName());
        stmt.setString(3, emp.getEmail());
        stmt.setString(4, emp.getPhoneNumber());
        stmt.setDate(5, emp.getDob());
        stmt.setString(6, emp.getGender());
        stmt.setString(7, emp.getJobTitle());
        stmt.setString(8, emp.getDepartment());
        stmt.setString(9, emp.getEmployeeType());
        stmt.setDate(10, emp.getDateOfJoining());
        stmt.setObject(11, emp.getManagerId(), java.sql.Types.INTEGER);
        stmt.setString(12, emp.getUsername());
        stmt.setString(13, emp.getPasswordHash());
        stmt.setString(14, emp.getRole());
        return stmt.executeUpdate() > 0;
    }

    // ✅ Get all employees
    public List<Employee> getAllEmployees() throws SQLException {
        List<Employee> list = new ArrayList<>();
        String sql = "SELECT * FROM Employee";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);

        while (rs.next()) {
            Employee emp = new Employee();
            emp.setEmployeeId(rs.getInt("employee_id"));
            emp.setFirstName(rs.getString("first_name"));
            emp.setLastName(rs.getString("last_name"));
            emp.setEmail(rs.getString("email"));
            emp.setPhoneNumber(rs.getString("phone_number"));
            emp.setDob(rs.getDate("dob"));
            emp.setGender(rs.getString("gender"));
            emp.setJobTitle(rs.getString("job_title"));
            emp.setDepartment(rs.getString("department"));
            emp.setEmployeeType(rs.getString("employee_type"));
            emp.setDateOfJoining(rs.getDate("date_of_joining"));
            emp.setManagerId(rs.getInt("manager_id"));
            emp.setEmployeeStatus(rs.getString("employee_status"));
            emp.setUsername(rs.getString("username"));
            emp.setRole(rs.getString("role"));
            list.add(emp);
        }

        return list;
    }

    // ✅ Delete employee by ID
    public boolean deleteEmployee(int id) throws SQLException {
        String sql = "DELETE FROM Employee WHERE employee_id = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, id);
        return stmt.executeUpdate() > 0;
    }

    // ✅ Get employee by ID
    public Employee getEmployeeById(int id) throws SQLException {
        String sql = "SELECT * FROM Employee WHERE employee_id = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            Employee emp = new Employee();
            emp.setEmployeeId(rs.getInt("employee_id"));
            emp.setFirstName(rs.getString("first_name"));
            emp.setLastName(rs.getString("last_name"));
            emp.setEmail(rs.getString("email"));
            emp.setPhoneNumber(rs.getString("phone_number"));
            emp.setDob(rs.getDate("dob"));
            emp.setGender(rs.getString("gender"));
            emp.setJobTitle(rs.getString("job_title"));
            emp.setDepartment(rs.getString("department"));
            emp.setEmployeeType(rs.getString("employee_type"));
            emp.setDateOfJoining(rs.getDate("date_of_joining"));
            emp.setManagerId(rs.getInt("manager_id"));
            emp.setEmployeeStatus(rs.getString("employee_status"));
            emp.setUsername(rs.getString("username"));
            emp.setRole(rs.getString("role"));
            return emp;
        }
        return null;
    }

    // ✅ Update employee
    public boolean updateEmployee(Employee emp) throws SQLException {
        String sql = "UPDATE Employee SET first_name=?, last_name=?, email=?, phone_number=?, dob=?, gender=?, job_title=?, department=?, employee_type=?, date_of_joining=?, manager_id=?, employee_status=? WHERE employee_id=?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, emp.getFirstName());
        stmt.setString(2, emp.getLastName());
        stmt.setString(3, emp.getEmail());
        stmt.setString(4, emp.getPhoneNumber());
        stmt.setDate(5, emp.getDob());
        stmt.setString(6, emp.getGender());
        stmt.setString(7, emp.getJobTitle());
        stmt.setString(8, emp.getDepartment());
        stmt.setString(9, emp.getEmployeeType());
        stmt.setDate(10, emp.getDateOfJoining());
        stmt.setObject(11, emp.getManagerId(), java.sql.Types.INTEGER);
        stmt.setString(12, emp.getEmployeeStatus());
        stmt.setInt(13, emp.getEmployeeId());
        return stmt.executeUpdate() > 0;
    }

    // ✅ Authenticate login
    public Employee authenticate(String username, String password) throws SQLException {
        String sql = "SELECT * FROM Employee WHERE username = ? AND password_hash = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, username);
        stmt.setString(2, password);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            Employee emp = new Employee();
            emp.setEmployeeId(rs.getInt("employee_id"));
            emp.setFirstName(rs.getString("first_name"));
            emp.setLastName(rs.getString("last_name"));
            emp.setUsername(rs.getString("username"));
            emp.setRole(rs.getString("role"));
            return emp;
        }
        return null;
    }

    // ✅ Get employee ID by username
    public int getEmployeeIdByUsername(String username) throws SQLException {
        String sql = "SELECT employee_id FROM Employee WHERE username = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, username);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            return rs.getInt("employee_id");
        }
        return -1; // Username not found
    }
}
