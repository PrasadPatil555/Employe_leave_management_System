package com.employeeleavesystem.dao;

import com.employeeleavesystem.model.Payroll;
import java.sql.*;
import java.util.*;

public class PayrollDAO {
    private Connection conn;

    public PayrollDAO(Connection conn) {
        this.conn = conn;
    }

    public boolean processPayroll(Payroll payroll) throws SQLException {
        String sql = "INSERT INTO Payroll (employee_id, salary, bank_account, tax_deductions, payment_date) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, payroll.getEmployeeId());
        stmt.setBigDecimal(2, payroll.getSalary());
        stmt.setString(3, payroll.getBankAccount());
        stmt.setBigDecimal(4, payroll.getTaxDeductions());
        stmt.setDate(5, payroll.getPaymentDate());
        return stmt.executeUpdate() > 0;
    }

    public List<Payroll> getPayrollByEmployee(int employeeId) throws SQLException {
        List<Payroll> list = new ArrayList<>();
        String sql = "SELECT * FROM Payroll WHERE employee_id = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, employeeId);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Payroll p = new Payroll();
            p.setPayrollId(rs.getInt("payroll_id"));
            p.setEmployeeId(rs.getInt("employee_id"));
            p.setSalary(rs.getBigDecimal("salary"));
            p.setBankAccount(rs.getString("bank_account"));
            p.setTaxDeductions(rs.getBigDecimal("tax_deductions"));
            p.setNetSalary(rs.getBigDecimal("net_salary"));
            p.setPaymentDate(rs.getDate("payment_date"));
            list.add(p);
        }
        return list;
    }
}
